# manufacturing-lm-01
notebooklm for manufacturing
